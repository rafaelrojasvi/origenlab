# Catálogo HTML → PDF (Playwright)

## Enfoque

Los spreads editoriales largos (dos columnas + grillas + tablas) **no fragmentan bien** solo con CSS de impresión: el motor empuja bloques enteros y deja huecos, o recorta si `.page` se comporta como caja A4 fija con `overflow: hidden`.

Por eso el HTML del catálogo **parte a mano** las secciones problemáticas en **varias** `<section class="page">` (misma numeración + “continuación”), y el `@media print` del documento fija:

- `.page` fluida en impresión (`overflow: visible`, `min-height: auto`, `break-after: page`);
- tablas con `break-inside: auto` en el contenedor y **filas** (`tr` / `td` / `th`) sin partir.

El script Playwright **no inyecta CSS en modo `multipage`**: confía en ese HTML + `page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true })`.

Referencias: [overflow (MDN)](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/overflow), [Playwright Page.pdf](https://playwright.dev/docs/api/class-page#page-pdf).

## Spreads partidos en el HTML

| Bloque | Página 1 | Página 2 |
|--------|----------|----------|
| **02 · SERVA** | Título + `two-pane` (hero, panorama, argumentos) | `02 · SERVA · continuación` + **Productos destacados** + `product-grid` |
| **04 · BIOCEN 22** | Título + `two-pane` + tarjetas Funciones / Seguridad | `04 · Ortoalresa · continuación` + **rotores disponibles** + tabla |
| **05 · BIOCEN 22 R** | Igual que arriba hasta las dos tarjetas | `05 · Ortoalresa · continuación` + tabla de rotores + nota accesorios |

## Requisitos

- Node.js 18+
- Una sola vez en `catalog-premium/`:

```bash
cd docs/origenlab-brochures/catalog-premium
npm install
npx playwright install chromium
```

**Nota:** Si el prompt ya muestra `catalog-premium`, no hagas otro `cd docs/origenlab-brochures/catalog-premium` (esa ruta no existe dentro de la carpeta actual).

## Uso (multi‑página A4)

```bash
cd docs/origenlab-brochures/catalog-premium
node export-catalog-pdf.mjs OrigenLab_Catalogo_Tecnico_Editorial_Imagenes_Premium.html catalog-multipage.pdf multipage
```

Desde la raíz del repo:

```bash
node docs/origenlab-brochures/catalog-premium/export-catalog-pdf.mjs OrigenLab_Catalogo_Tecnico_Editorial_Imagenes_Premium.html catalog-multipage.pdf multipage
```

Atajo: `npm run pdf`

## Modo continuo (una sola página PDF larga)

Sin paginación A4; usa **media screen** + alto total del documento:

```bash
node export-catalog-pdf.mjs OrigenLab_Catalogo_Tecnico_Editorial_Imagenes_Premium.html catalog-continuous.pdf continuous
```

## Qué hace el script

1. Sirve la carpeta del HTML por HTTP (assets relativos OK).
2. Carga la página, espera red e imágenes.
3. **`multipage`:** PDF A4, fondos activos, sin inyección de estilos.
4. **`continuous`:** `emulateMedia('screen')`, viewport ancho, mide `scrollWidth` / `scrollHeight`, PDF con esas dimensiones en px.

## Salida en git

`node_modules/` suele ignorarse. Añade `*.pdf` si no quieres commitear exports.
